# Arahan Assistant — Android

پروژه کامل Android برنامه **Arahan Assistant** با شناسه `com.arahan.assistant`، نسخه `1.0.0`، حداقل API 23 و هدف API 35.

## ساخت با GitHub Actions

1. کل محتوای این پروژه را در ریشه یک مخزن GitHub قرار دهید.
2. از زبانه **Actions**، گردش‌کار **Build Arahan Assistant APK** را باز کنید.
3. برای اجرای دستی، گزینه **Run workflow** را بزنید؛ این پروژه `workflow_dispatch` را فعال دارد.
4. Workflow، Java 17، Android SDK API 35 و مجوز اجرایی Gradle Wrapper را تنظیم می‌کند و دستور زیر را اجرا می‌کند:

```bash
./gradlew assembleDebug
```

5. پس از موفقیت، از بخش **Artifacts** مورد `Arahan-Assistant-apk` را دانلود کنید.
6. فایل داخل artifact با نام زیر است:

```text
app-debug.apk
```

## ساخت محلی

```bash
./gradlew assembleDebug
```

خروجی در `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.
